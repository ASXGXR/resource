#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

// The game's own 1.21.11 GUI sprite shader, plus Poliiglotia's compass at the top (the user: "maybe add it to the
// top bar instead"): every locator bar sprite (compass marks, the bar, other players' dots) has MARK in its corners
// (tools/style/hudfont.py) and is moved from above the hotbar to under the place line. The game still slides the
// marks as you turn, so it stays instant.

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform sampler2D Sampler0;

out vec2 texCoord0;
out vec4 vertexColor;

const ivec4 MARK = ivec4(254, 1, 253, 1);
const ivec4 MARK_LOW = ivec4(254, 1, 252, 1); // the same, then LOW under the bar: a city or house that would cover
                                              // a letter (the user: "A city icon should not cover up west")
const float BAR_TOP = 16.0; // the bar's top edge, in GUI pixels from the top of the screen
const float GAME_TOP = 29.0; // where the game draws it: this far above the bottom
const float LOW = 10.0;

void main() {
    vec3 pos = Position;
    int corner = gl_VertexID % 4; // the game's sprite quads: top left, bottom left, bottom right, top right
    ivec2 size = textureSize(Sampler0, 0);
    ivec2 inside = ivec2(round(UV0 * vec2(size))) - ivec2(corner >= 2 ? 1 : 0, (corner == 1 || corner == 2) ? 1 : 0);
    if (all(greaterThanEqual(inside, ivec2(0))) && all(lessThan(inside, size))) {
        ivec4 texel = ivec4(round(texelFetch(Sampler0, inside, 0) * 255.0));
        if (texel == MARK || texel == MARK_LOW) {
            float height = 2.0 / abs(ProjMat[1][1]);
            pos.y += BAR_TOP - (height - GAME_TOP) + (texel == MARK_LOW ? LOW : 0.0);
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    texCoord0 = UV0;
    vertexColor = Color;
}
