#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

// The game's own 1.21.11 text shader, plus Poliiglotia's coordinates: the Compass plugin puts one digit slot per
// character of each coordinate on the place line (the hud font's , "0123456789-" at 6 px a cell, MARK in
// its corners: tools/style/hudfont.py), coloured red 252, green 4 * (axis + 4 * pose), blue 4 * slot; axis 0 x,
// 1 y, 2 z; pose (sent by the server when it changes) picks the eye height, as the camera sits that far above the
// feet. Here each slot becomes that character of the camera's own block position, so the numbers never wait for
// the server. The shadow copy is the colour / 4 (red 63, green axis + 4 * pose, blue slot).

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const ivec4 MARK = ivec4(254, 1, 253, 1);
const float CELL = 6.0;
const float CELLS = 11.0;
// camera height above the feet per pose: standing, sneaking, swimming / gliding / crawling, sleeping
const float EYES[4] = float[](1.62, 1.27, 0.4, 0.2);
const vec3 FAINT = vec3(125.0, 117.0, 144.0) / 255.0; // the style guide's Faint (#7D7590)

// The character at slot of v ("-" first when negative): 0-9 a digit, 10 the minus, -1 none
int character(int v, int slot) {
    int a = abs(v);
    int digits = 1;
    for (int t = a; t >= 10; t /= 10) digits++;
    int sign = v < 0 ? 1 : 0;
    if (slot >= digits + sign) return -1;
    if (sign == 1 && slot == 0) return 10;
    for (int p = digits - 1 - (slot - sign); p > 0; p--) a /= 10;
    return a % 10;
}

void main() {
    vec3 pos = Position;
    vec2 uv = UV0;
    vec4 colour = Color;

    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r == 252 || c.r == 63) {
        int corner = gl_VertexID % 4; // the game's glyph quads: top left, bottom left, bottom right, top right
        bool right = corner >= 2;
        ivec2 size = textureSize(Sampler0, 0);
        ivec2 inside = ivec2(round(UV0 * vec2(size))) - ivec2(right ? 1 : 0, (corner == 1 || corner == 2) ? 1 : 0);
        if (all(greaterThanEqual(inside, ivec2(0))) && all(lessThan(inside, size))
                && ivec4(round(texelFetch(Sampler0, inside, 0) * 255.0)) == MARK) {
            bool shadow = c.r == 63;
            int g = shadow ? c.g : c.g / 4;
            int axis = g % 4;
            int slot = shadow ? c.b : c.b / 4;
            vec3 camera = vec3(CameraBlockPos) - CameraOffset;
            // + 0.01: standing on a block the feet are a whole number, and float rounding could tip it one under
            float value = axis == 0 ? camera.x : axis == 1 ? camera.y - EYES[min(g / 4, 3)] + 0.01 : camera.z;
            int ch = character(int(floor(value)), slot);
            // one cell wide (none for an empty slot), showing that character's cell of the strip
            if (right) pos.x -= ch < 0 ? CELL * CELLS : CELL * (CELLS - 1.0);
            float du = CELL / float(size.x);
            if (ch >= 0) uv.x += right ? -(CELLS - 1.0 - float(ch)) * du : float(ch) * du;
            colour = vec4(FAINT * (shadow ? 0.25 : 1.0), Color.a);
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = colour * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = uv;
}
